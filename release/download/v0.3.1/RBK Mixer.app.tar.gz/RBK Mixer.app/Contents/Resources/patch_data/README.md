# CT-X Tone List

BankMSB and Patch numbers for tone in the CT-X5000 and CT-X3000 keyboards. The data is correct
also for CT-X700 and CT-X800 provided 3-digit voice number is disregarded.

Acknowledgement
===============

Many thanks to McLandy from Casio Music Forums for providing this data

# AiX Forced Stereo Tones

BankMSB and Patch numbers for tones that are _not_ fully compatible with mono playing, i.e.
even when fully panned left or right there will be sound leakage in the opposite channel

Acknowledgement
===============

Many thanks to Chandler Holloway from Casio Music Forums for providing this data

